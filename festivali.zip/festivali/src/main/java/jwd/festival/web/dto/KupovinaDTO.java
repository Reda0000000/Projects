package jwd.festival.web.dto;

public class KupovinaDTO {
	Long id;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
}
