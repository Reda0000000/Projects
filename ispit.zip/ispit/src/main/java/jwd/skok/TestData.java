package jwd.skok;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import jwd.skok.model.Skakaonica;
import jwd.skok.model.Takmicar;
import jwd.skok.service.SkakaonicaService;
import jwd.skok.service.TakmicarService;


@Component
public class TestData {

	@Autowired
	private SkakaonicaService skakaonicaService;
	
	@Autowired
	private TakmicarService takmicarService;
	
	@PostConstruct
	public void init() {
		
		Skakaonica s1 = new Skakaonica();
		s1.setNaziv("Mala skakaonica");
		s1.setK(3);
		s1.setD(4);
		skakaonicaService.save(s1);
		
		Skakaonica s2 = new Skakaonica();
		s2.setNaziv("Velika skakaonica");
		s2.setK(33);
		s2.setD(44);
		skakaonicaService.save(s2);
		
		Takmicar t1 = new Takmicar();
		t1.setImeIPrezime("Mile Milic");
		t1.setDrzava("Rusija");
		t1.setVisina(1991);
		t1.setEmail("gasd@hotmail.rs");
		t1.setGodinaRodjenja(2);
		t1.setSkakaonica(s1);
		
		takmicarService.save(t1);
		
		Takmicar t2 = new Takmicar();
		t2.setImeIPrezime("Nikola Nikolic");
		t2.setDrzava("Danka");
		t2.setVisina(192);
		t2.setEmail("gas232d@hotmail.rs");
		t2.setGodinaRodjenja(5);
		t2.setSkakaonica(s2);
		
		takmicarService.save(t1);
	}
}