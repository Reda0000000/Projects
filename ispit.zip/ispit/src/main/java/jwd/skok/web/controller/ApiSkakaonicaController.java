package jwd.skok.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import jwd.skok.model.Skakaonica;
import jwd.skok.model.Takmicar;
import jwd.skok.service.SkakaonicaService;
import jwd.skok.service.TakmicarService;
import jwd.skok.support.SkakaonicaToSkakaonicaDTO;
import jwd.skok.support.TakmicarToTakmicarDTO;
import jwd.skok.web.dto.SkakaonicaDTO;
import jwd.skok.web.dto.TakmicarDTO;

@RestController
@RequestMapping("/api/skakaonice")
public class ApiSkakaonicaController {

	@Autowired
	private SkakaonicaService skakaonicaService;
	@Autowired
	private TakmicarService takmicarService;
	@Autowired
	private SkakaonicaToSkakaonicaDTO toDTO;
	@Autowired
	private TakmicarToTakmicarDTO toTakmicarDTO;
	
	@RequestMapping(method=RequestMethod.GET)
	public ResponseEntity<List<SkakaonicaDTO>> get(){
		return new ResponseEntity<>(
				toDTO.convert(skakaonicaService.findAll()),
				HttpStatus.OK);
	}
	
	@RequestMapping(value="/{id}", method=RequestMethod.GET)
	public ResponseEntity<SkakaonicaDTO> get(
			@PathVariable Long id){
		
		Skakaonica skakaonica = skakaonicaService.findOne(id);
		
		if(skakaonica == null){
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<>(
				toDTO.convert(skakaonica),
				HttpStatus.OK);
	}
	
	@RequestMapping(value="/{skakaonicaId}/automobili")
	public ResponseEntity<List<TakmicarDTO>> takmicariSkakaonica(
			@PathVariable Long skakaonicaId,
			@RequestParam(defaultValue="0") int pageNum){
		Page<Takmicar> takmicari = takmicarService.findBySkakaonicaId(pageNum, skakaonicaId);
		
		HttpHeaders headers = new HttpHeaders();
		headers.add("totalPages", Integer.toString(takmicari.getTotalPages()) );
		return  new ResponseEntity<>(
				toTakmicarDTO.convert(takmicari.getContent()),
				headers,
				HttpStatus.OK);
	}
}
