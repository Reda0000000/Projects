package jwd.skok.web.dto;

public class SkokDTO {

	private Long id;
	private double daljina;
	private double ocenaSudija;
	private double zbirPoena;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public double getDaljina() {
		return daljina;
	}
	public void setDaljina(double daljina) {
		this.daljina = daljina;
	}
	public double getOcenaSudija() {
		return ocenaSudija;
	}
	public void setOcenaSudija(double ocenaSudija) {
		this.ocenaSudija = ocenaSudija;
	}
	public double getZbirPoena() {
		return zbirPoena;
	}
	public void setZbirPoena(double zbirPoena) {
		this.zbirPoena = zbirPoena;
	}
	
	
	
}
