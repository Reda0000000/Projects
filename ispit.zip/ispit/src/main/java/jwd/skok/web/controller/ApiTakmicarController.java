package jwd.skok.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import jwd.skok.model.Takmicar;
import jwd.skok.service.TakmicarService;
import jwd.skok.support.TakmicarDTOToTakmicar;
import jwd.skok.support.TakmicarToTakmicarDTO;
import jwd.skok.web.dto.TakmicarDTO;

@RestController
@RequestMapping("/api/takmicari")
public class ApiTakmicarController {
	
	@Autowired
	private TakmicarService takmicarService;
	@Autowired
	private TakmicarToTakmicarDTO toTakmicarDTO;
	@Autowired
	private TakmicarDTOToTakmicar toTakmicar;
	
	@RequestMapping(method=RequestMethod.GET)
	public ResponseEntity<List<TakmicarDTO>> get(
			@Param("idSkakaonice") Long idSkakaonice, 
			@Param("imeIPrezime") String imeIPrezime, 
			@Param("drzava") String drzava,
			@RequestParam(defaultValue="0") int pageNum){
		
		Page<Takmicar> takmicari;
		
		if(idSkakaonice != null || imeIPrezime != null || drzava != null) {
			takmicari = takmicarService.pretraga(idSkakaonice, imeIPrezime, drzava, pageNum);
		}else{
			takmicari = takmicarService.findAll(pageNum);
		}
		
		HttpHeaders headers = new HttpHeaders();
		headers.add("totalPages", Integer.toString(takmicari.getTotalPages()) );
		return  new ResponseEntity<>(
				toTakmicarDTO.convert(takmicari.getContent()),
				headers,
				HttpStatus.OK);
	}
	
	@RequestMapping(method=RequestMethod.GET,
			value="/{id}")
		public ResponseEntity<TakmicarDTO> get(
			@PathVariable Long id){
		Takmicar takmicar = takmicarService.findOne(id);
		
		if(takmicar==null){
			return  new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<>(
				toTakmicarDTO.convert(takmicar),
				HttpStatus.OK);	
		}
		
		@RequestMapping(method=RequestMethod.POST)
		public ResponseEntity<TakmicarDTO> add(
			@Validated @RequestBody TakmicarDTO noviTakmicar){
		
		Takmicar takmicar = toTakmicar.convert(noviTakmicar); 
		takmicarService.save(takmicar);
		
		return new ResponseEntity<>(toTakmicarDTO.convert(takmicar),
				HttpStatus.CREATED);
		}
		
		@RequestMapping(method=RequestMethod.PUT,
			value="/{id}")
		public ResponseEntity<TakmicarDTO> edit(
			@PathVariable Long id,
			@Validated @RequestBody TakmicarDTO izmenjen){
		
		if(!id.equals(izmenjen.getId())){
			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}
		
		Takmicar takmicar = toTakmicar.convert(izmenjen); 
		takmicarService.save(takmicar);
		
		return new ResponseEntity<>(toTakmicarDTO.convert(takmicar),
				HttpStatus.OK);
		}
		
		@RequestMapping(method=RequestMethod.DELETE,
			value="/{id}")
		public ResponseEntity<TakmicarDTO> delete(@PathVariable Long id){
		
			Takmicar deleted = takmicarService.remove(id);
		if(deleted == null) {
			return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
		
		return new ResponseEntity<>(
				toTakmicarDTO.convert(deleted),
				HttpStatus.OK);
		}
		
//		@RequestMapping(method=RequestMethod.POST, value="/{id}/iznajmljivanje")
//		public ResponseEntity<NajamDTO> rent(@PathVariable Long id){
//		
//		Najam n = najamService.rentACar(id);
//		
//		if(n != null) {
//			return new ResponseEntity<>(toNajamDTO.convert(n), HttpStatus.CREATED);
//		}
//		else {
//			return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
//		}
//		}
		
		@ExceptionHandler
		public ResponseEntity<Void> validationHandler(
					DataIntegrityViolationException e){
		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
		}

}
