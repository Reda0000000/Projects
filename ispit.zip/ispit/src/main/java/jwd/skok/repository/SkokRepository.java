package jwd.skok.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import jwd.skok.model.Skok;


@Repository
public interface SkokRepository extends JpaRepository<Skok, Long>{

}
