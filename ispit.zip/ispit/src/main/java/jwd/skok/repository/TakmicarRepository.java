package jwd.skok.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import jwd.skok.model.Takmicar;

@Repository
public interface TakmicarRepository extends JpaRepository<Takmicar, Long>{

	Page<Takmicar> findBySkakaonicaId(Long skakaonicaId, Pageable pageRequest);
	
	@Query("SELECT t FROM Takmicar t WHERE "
			+ "(:idSkakaonice IS NULL or t.skakaonica.id = :idSkakaonice ) AND "
			+ "(:imeIPrezime IS NULL OR t.imeIPrezime like :imeIPrezime) AND "
			+ "(:drzava IS NULL or t.drzava like :drzava )"
			)
	Page<Takmicar> pretraga(
			@Param("idSkakaonice") Long idSkakaonice, 
			@Param("imeIPrezime") String imeIPrezime, 
			@Param("drzava") String drzava,
			Pageable pageRequest);
	
}
