package jwd.skok.service.impl;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;


import jwd.skok.model.Takmicar;
import jwd.skok.repository.TakmicarRepository;
import jwd.skok.service.TakmicarService;

@Service
@Transactional
public class JpaTakmicarServiceImpl implements TakmicarService{
	
	@Autowired
	private TakmicarRepository takmicarRepository;

	@Override
	public Page<Takmicar> findAll(int pageNum) {
		return takmicarRepository.findAll(
		new PageRequest(pageNum, 5));
	}

	@Override
	public Takmicar findOne(Long id) {
		return takmicarRepository.findOne(id);
	}

	@Override
	public void save(Takmicar takmicar) {
		takmicarRepository.save(takmicar);
		
	}

	@Override
	public Takmicar remove(Long id) {
		Takmicar takmicar = takmicarRepository.findOne(id);
		if(takmicar != null) {
			takmicarRepository.delete(takmicar);
		}
		
		return takmicar;
	}
	

	@Override
	public Page<Takmicar> findBySkakaonicaId(int pageNum, Long skakaonicaId) {
		return takmicarRepository.findBySkakaonicaId(skakaonicaId, new PageRequest(pageNum, 5));
	}

	@Override
	public Page<Takmicar> pretraga(Long idSkakaonice, String imeIPrezime, String drzava, int page) {
		if(imeIPrezime != null ){
			imeIPrezime = "%" + imeIPrezime + "%";
		}
		return takmicarRepository.pretraga(idSkakaonice, imeIPrezime, drzava, new PageRequest(page, 5));
	}
	}

	


