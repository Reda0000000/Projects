package jwd.skok.service;

import java.util.List;

import jwd.skok.model.Skakaonica;

public interface SkakaonicaService {
	List<Skakaonica> findAll();
	Skakaonica findOne(Long id);
	void save(Skakaonica skakaonica);
	void remove(Long id);

}
