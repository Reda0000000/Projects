package jwd.skok.service.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import jwd.skok.model.Skakaonica;
import jwd.skok.repository.SkakaonicaRepository;
import jwd.skok.service.SkakaonicaService;

@Service
@Transactional
public class JpaSkakaonicaServiceImpl implements SkakaonicaService{
	
	@Autowired
	private SkakaonicaRepository skakaonicaRepository;

	@Override
	public List<Skakaonica> findAll() {
		return skakaonicaRepository.findAll();
	}

	@Override
	public Skakaonica findOne(Long id) {
		return skakaonicaRepository.findOne(id);
	}

	@Override
	public void save(Skakaonica skakaonica) {
		skakaonicaRepository.save(skakaonica);
		
	}

	@Override
	public void remove(Long id) {
		skakaonicaRepository.delete(id);
		
	}

}
