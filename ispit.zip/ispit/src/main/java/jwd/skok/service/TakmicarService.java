package jwd.skok.service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.query.Param;

import jwd.skok.model.Takmicar;

public interface TakmicarService {

	Page<Takmicar> findAll(int pageNum);
	Takmicar findOne(Long id);
	void save(Takmicar takmicar);
	Takmicar remove(Long id);
	Page<Takmicar> findBySkakaonicaId(int pageNum, Long skakonicaId);
	Page<Takmicar> pretraga(
			@Param("idSkakaonice") Long idSkakaonice, 
			@Param("imeIPrezime") String imeIPrezime, 
			@Param("drzava") String drzava,
			int page);
}
