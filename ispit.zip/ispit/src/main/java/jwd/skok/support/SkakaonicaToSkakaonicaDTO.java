package jwd.skok.support;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;


import jwd.skok.model.Skakaonica;
import jwd.skok.web.dto.SkakaonicaDTO;

@Component
public class SkakaonicaToSkakaonicaDTO implements Converter<Skakaonica, SkakaonicaDTO>{

	@Override
	public SkakaonicaDTO convert(Skakaonica skakaonica) {
		SkakaonicaDTO skakaonicaDTO = new SkakaonicaDTO();
		skakaonicaDTO.setId(skakaonica.getId());
		skakaonicaDTO.setNaziv(skakaonica.getNaziv());
		skakaonicaDTO.setK(skakaonica.getK());
		skakaonicaDTO.setD(skakaonica.getD());
		return skakaonicaDTO;
	}

	public List<SkakaonicaDTO> convert(List<Skakaonica> skakaonice) {
		List<SkakaonicaDTO> ret = new ArrayList<>();
		
		for(Skakaonica s: skakaonice){
			ret.add(convert(s));
		}
		
		return ret;
		
	}
}
