package jwd.skok.support;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;


import jwd.skok.model.Skakaonica;
import jwd.skok.model.Takmicar;
import jwd.skok.service.SkakaonicaService;
import jwd.skok.service.TakmicarService;
import jwd.skok.web.dto.TakmicarDTO;

@Component
public class TakmicarDTOToTakmicar implements Converter<TakmicarDTO, Takmicar>{
	
	@Autowired
	private TakmicarService takmicarService;
	@Autowired
	private SkakaonicaService skakaonicaService;

	
	@Override
	public Takmicar convert(TakmicarDTO source) {
		Takmicar takmicar;
		Skakaonica s = skakaonicaService.findOne(source.getSkakaonicaId());
		
		if(source.getId()==null){
			takmicar = new Takmicar();
		}else{
			takmicar = takmicarService.findOne(source.getId());
		}
		
		takmicar.setSkakaonica(s);
		
		takmicar.setImeIPrezime(source.getImeIPrezime());
		takmicar.setDrzava(source.getDrzava());
		takmicar.setVisina(source.getVisina());
		takmicar.setEmail(source.getEmail());
		takmicar.setGodinaRodjenja(source.getGodinaRodjenja());
		
		return takmicar;
	}
}
