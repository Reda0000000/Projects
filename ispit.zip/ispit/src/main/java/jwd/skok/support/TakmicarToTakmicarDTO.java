package jwd.skok.support;

import java.util.ArrayList;
import java.util.List;

import org.springframework.core.convert.converter.Converter;
import org.springframework.stereotype.Component;


import jwd.skok.model.Takmicar;
import jwd.skok.web.dto.TakmicarDTO;

@Component
public class TakmicarToTakmicarDTO implements Converter<Takmicar, TakmicarDTO>{

	@Override
	public TakmicarDTO convert(Takmicar source) {
		TakmicarDTO dto = new TakmicarDTO();
		dto.setId(source.getId());
		dto.setImeIPrezime(source.getImeIPrezime());
		dto.setDrzava(source.getDrzava());
		dto.setVisina(source.getVisina());
		dto.setEmail(source.getEmail());
		dto.setGodinaRodjenja(source.getGodinaRodjenja());
		dto.setSkakaonicaId(source.getSkakaonica().getId());
		dto.setSkakaonicaNaziv(source.getSkakaonica().getNaziv());
		
		return dto;
	}
	
	public List<TakmicarDTO> convert(List<Takmicar> takmicari){
		List<TakmicarDTO> ret = new ArrayList<>();
		
		for(Takmicar t : takmicari){
			ret.add(convert(t));
		}
		
		return ret;
	}
}
