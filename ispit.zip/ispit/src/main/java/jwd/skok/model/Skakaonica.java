package jwd.skok.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;


@Entity
public class Skakaonica {

	@Id
	@GeneratedValue
	@Column
	private Long id;
	
	@Column(unique = true)
	private String naziv;
	
	@Column
	private int k;
	
	@Column
	private double d;
	
	@OneToMany(mappedBy="skakaonica",fetch=FetchType.LAZY,cascade=CascadeType.ALL)
	private List<Takmicar> takmicari = new ArrayList<>();

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getNaziv() {
		return naziv;
	}

	public void setNaziv(String naziv) {
		this.naziv = naziv;
	}

	public int getK() {
		return k;
	}

	public void setK(int k) {
		this.k = k;
	}

	

	public double getD() {
		return d;
	}

	public void setD(double d) {
		this.d = d;
	}

	public List<Takmicar> getTakmicari() {
		return takmicari;
	}

	public void setTakmicari(List<Takmicar> takmicari) {
		this.takmicari = takmicari;
	}
	
	public void addTakmicar(Takmicar takmicar){
		this.takmicari.add(takmicar);
		
		if(!this.equals(takmicar.getSkakaonica())){
			takmicar.setSkakaonica(this);
		}
	}
}
