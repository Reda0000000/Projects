var skokApp = angular.module("skokApp", ['ngRoute']);

skokApp.config(['$routeProvider', function ($routeProvider) {
    $routeProvider.when('/',{
        templateUrl: '/app/html/takmicari.html'
    }).when('/takmicari/edit/:id',{
        templateUrl: '/app/html/edit-takmicar.html'
    }).otherwise({
        redirectTo: '/'
    });
}]);

skokApp.controller("takmicariCtrl", function($scope, $http, $location){

	var baseUrlSkakaonice = "/api/skakaonice";
    var baseUrlTakmicari = "/api/takmicari";
    

    $scope.pageNum = 0;
    $scope.totalPages = 0;

    $scope.skakaonice = [];
    $scope.takmicari = [];

    $scope.noviTakmicar = {};
    $scope.noviTakmicar.imeIPrezime = "";
    $scope.noviTakmicar.drzava = "";
    $scope.noviTakmicar.visina = "";
    $scope.noviTakmicar.godinaRodjenja = "";
    $scope.noviTakmicar.email = "";
    $scope.noviTakmicar.skakaonicaId = "";
    


    $scope.trazeniTakmicar = {};
    $scope.trazeniTakmicar.skakaonicaId = "";
    $scope.trazeniTakmicar.imeIPrezime = "";
    $scope.trazeniTakmicar.drzava = "";

    var getTakmicari = function(){

        var config = {params: {}};

        config.params.pageNum = $scope.pageNum;

        if($scope.trazeniTakmicar.skakaonicaId != ""){
            config.params.skakaonicaId = $scope.trazeniTakmicar.skakaonicaId;
        }

        if($scope.trazeniTakmicar.imeIPrezime != ""){
            config.params.imeIPrezime = $scope.trazeniTakmicar.imeIPrezime;
        }

        if($scope.trazeniTakmicar.drzava != ""){
            config.params.drzava = $scope.trazeniTakmicar.drzava;
        }


        $http.get(baseUrlTakmicari, config)
            .then(
            	function success(res){
            		$scope.takmicari = res.data;
            		$scope.totalPages = res.headers('totalPages');
            	},
            	function error(res){
            		alert("Neuspesno dobavljanje takmicara!");
            	}
            );
    };

    var getSkakaonice = function(){

        $http.get(baseUrlSkakaonice)
            .then(
            	function success(res){
            		$scope.skakaonice = res.data;
            	},
            	function error(res){
            		alert("Neuspesno dobavljanje skakaonice!");
            	}
            );

    };

    getSkakaonice();
    getTakmicari();
   

    $scope.nazad = function(){
        if($scope.pageNum > 0) {
            $scope.pageNum = $scope.pageNum - 1;
            getTakmicari();
        }
    };

    $scope.napred = function(){
        if($scope.pageNum < $scope.totalPages - 1){
            $scope.pageNum = $scope.pageNum + 1;
            getTakmicari();
        }
    };

    $scope.dodaj = function(){
        $http.post(baseUrlTakmicari, $scope.noviTakmicar)
            .then(
            	function success(res){
            		getTakmicari();
	
            		$scope.noviTakmicar.imeIPrezime = "";
            	    $scope.noviTakmicar.drzava = "";
            	    $scope.noviTakmicar.visina = "";
            	    $scope.noviTakmicar.godinaRodjenja = "";
            	    $scope.noviTakmicar.email = "";
            	    $scope.noviTakmicar.kompanijaId = "";
            	},
            	function error(res){
            		alert("Neuspesno dodavanje!");
            	}
            );
    };

    $scope.trazi = function () {
        $scope.pageNum = 0;
        getTakmicari();
    }

    $scope.izmeni = function(id){
        $location.path('/takmicari/edit/' + id);
    }

    $scope.obrisi = function(id){
        $http.delete(baseUrlTakmicari + "/" + id).then(
            function success(data){
            	getTakmicari();
            },
            function error(data){
                alert("Neuspesno brisanje!");
            }
        );
    }
    
//    $scope.iznajmi = function(id){
//    	$http.post(baseUrlAutomobili + "/" + id + "/iznajmljivanje").then(
//    		function success(data){
//    			alert("Automobil je uspesno iznajmljen.");
//    			getAutomobili();
//    		},
//    		function error(data){
//    			alert("Nije uspelo iznajmljivanje")
//    		}
//    	)
//    }
});

skokApp.controller("editTakmicarCtrl", function($scope, $http, $routeParams, $location){

	var baseUrlSkakaonice = "/api/skakaonice";
	var baseUrlTakmicari = "/api/takmicari";

    $scope.stariTakmicar = null;

    var getStariTakmicar = function(){

        $http.get(baseUrlTakmicari + "/" + $routeParams.id)
            .then(
            	function success(res){
            		$scope.stariTakmicar = res.data;
            	},
            	function error(data){
            		alert("Neušpesno dobavljanje takmicara.");
            	}
            );

    }
    
    getStariTakmicar();
    
    var getSkakaonice = function(){

        $http.get(baseUrlSkakaonice)
            .then(
            	function success(res){
            		$scope.skakaonice = res.data;
            		
            	},
            	function error(res){
            		alert("Neuspesno dobavljanje skakaonice!");
            	}
            );

    };

    getSkakaonice();
    
    $scope.izmeni = function(){
        $http.put(baseUrlTakmicari + "/" + $scope.stariTakmicar.id, $scope.stariTakmicar)
            .then(
        		function success(data){
        			alert("Uspešno izmenjen takmicar!");
        			$location.path("/");
        		},
        		function error(data){
        			alert("Neuspešna izmena takmicara.");
        		}
            );
    }
});

